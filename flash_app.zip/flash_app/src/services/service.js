import http from "../http-common";

class RegistroDataService {
  getAll() {
    return http.get("/registros");
  }

  get(id) {
    return http.get(`/registros/${id}`);
  }

  create(data) {
    return http.post("/registros", data);
  }

  update(id, data) {
    return http.put(`/registros/${id}`, data);
  }

  // update(id, data) {
  //   return http.put(`/registros/funcionarios`, data);
  // }

  deleteAll() {
    return http.delete(`/registros`);
  }
}

export default new RegistroDataService();