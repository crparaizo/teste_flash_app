import React, { Component } from "react";
import RegistroDataService from "../services/service";

export default class Registro extends Component {
  constructor(props) {
    super(props);
    this.onChangeNomeFuncionario = this.onChangeNomeFuncionario.bind(this);
    this.onChangeSobrenome = this.onChangeSobrenome.bind(this);
    this.onChangeCpf = this.onChangeCpf.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);

    this.getRegistro = this.getRegistro.bind(this);
    this.updateRegistro = this.updateRegistro.bind(this);

    this.state = {
      currentRegistro: {
        id: null,
        nome_empresa: "",
        nome_fantasia: "",
        cnpj: "",
        endereco: "",
        funcionarios: [{
          nome_funcionario: "",
          sobrenome: "",
          cpf: "",
          email: ""
        }],
      },
      message: ""
    };
  }

  componentDidMount() {
    this.getRegistro(this.props.match.params.id);
  }

  onChangeNomeFuncionario(e) {
    const nome_funcionario = e.target.value;

    this.setState(function (prevState) {
      return {

        currentRegistro: {
          ...prevState.currentRegistro,
          nome_funcionario: nome_funcionario
          // funcionarios: [{ nome_funcionario: nome_funcionario }]
        }
      };
    });
  }

  onChangeSobrenome(e) {
    const sobrenome = e.target.value;

    this.setState(prevState => ({
      currentRegistro: {
        ...prevState.currentRegistro,
        sobrenome: sobrenome
        // funcionarios: [{ sobrenome: sobrenome }]
      }
    }));
  }

  onChangeCpf(e) {
    const cpf = e.target.value;

    this.setState(function (prevState) {
      return {
        currentRegistro: {
          ...prevState.currentRegistro,
          cpf: cpf
          //funcionarios: [{ cpf: cpf }]
        }
      };
    });
  }

  onChangeEmail(e) {
    const email = e.target.value;

    this.setState(prevState => ({
      currentRegistro: {
        ...prevState.currentRegistro,
        email: email
        //funcionarios: [{ email: email }]
      }
    }));
  }

  getRegistro(id) {
    RegistroDataService.get(id)
      .then(response => {
        this.setState({
          currentRegistro: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  updateRegistro() {
    RegistroDataService.update(
      this.state.currentRegistro.id,
      this.state.currentRegistro
    )
      .then(response => {
        console.log(response.data);
        this.setState({
          message: "The Registro was updated successfully!"
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { currentRegistro } = this.state;

    return (
      <div>
        {currentRegistro ? (
          <div className="edit-form">
            <h4>Registro</h4>
            <form>
              <div className="form-group">
                <label htmlFor="nome_funcionario">Nome Funcionario</label>
                <input
                  type="text"
                  className="form-control"
                  id="nome_funcionario"
                  value={currentRegistro.funcionarios.nome_funcionario}
                  onChange={this.onChangeNomeFuncionario}
                />
              </div>
              <div className="form-group">
                <label htmlFor="sobrenome">Sobrenome</label>
                <input
                  type="text"
                  className="form-control"
                  id="sobrenome"
                  value={currentRegistro.funcionarios.sobrenome}
                  onChange={this.onChangeSobrenome}
                />
              </div>
              <div className="form-group">
                <label htmlFor="cpf">CPF</label>
                <input
                  type="text"
                  className="form-control"
                  id="cpf"
                  value={currentRegistro.funcionarios.cpf}
                  onChange={this.onChangeCpf}
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">E-mail</label>
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  value={currentRegistro.funcionarios.email}
                  onChange={this.onChangeEmail}
                />
              </div>

            </form>

            <button
              type="submit"
              className="badge badge-success"
              onClick={this.updateRegistro}
            >
              Enviar infos...
            </button>
            <p>{this.state.message}</p>
          </div>
        ) : (
            <div>
              <br />
              <p>Click no nome da empresa para expandir suas infos...</p>
            </div>
          )}
      </div>
    );
  }
}