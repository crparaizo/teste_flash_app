import React, { Component } from "react";
import RegistroDataService from "../services/service";
import { Link } from "react-router-dom";
import { Table } from "antd"

export default class RegistrosList extends Component {
  constructor(props) {
    super(props);
    this.Registros = this.retrieveRegistros.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.setActiveRegistro = this.setActiveRegistro.bind(this);
    this.removeAllRegistros = this.removeAllRegistros.bind(this);

    this.state = {
      registros: [],
      currentRegistro: null,
      currentIndex: -1
    };
  }

  componentDidMount() {
    this.retrieveRegistros();
  }


  retrieveRegistros() {
    RegistroDataService.getAll()
      .then(response => {
        this.setState({
          registros: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveRegistros();
    this.setState({
      currentRegistro: null,
      currentIndex: -1
    });
  }

  setActiveRegistro(registro, index) {
    this.setState({
      currentRegistro: registro,
      currentIndex: index
    });
  }

  removeAllRegistros() {
    RegistroDataService.deleteAll()
      .then(response => {
        console.log(response.data);
        this.refreshList();
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { registros, currentRegistro, currentIndex } = this.state;

    // const dataSource = [ ];

    // const columns = [ ];

    return (

      <div className="list row">
        {/* <Table dataSource={dataSource} columns={columns} />; */}
        <div className="col-md-6">
          <h4>Lista de Empresas</h4>

          <ul className="list-group">
            {registros &&
              registros.map((registro, index) => (
                <li
                  className={
                    "list-group-item " +
                    (index === currentIndex ? "active" : "")
                  }
                  onClick={() => this.setActiveRegistro(registro, index)}
                  key={index}
                >
                  {registro.nome_empresa}
                </li>
              ))}
          </ul>

          <button
            className="m-3 btn btn-sm btn-danger"
            onClick={this.removeAllRegistros}
          >
            Deletar TUDO
          </button>
        </div>
        <div className="col-md-6">
          {currentRegistro ? (
            <div>
              <h4>Registros</h4>
              <div>
                <label>
                  <strong>Empresa:</strong>
                </label>{" "}
                {currentRegistro.nome_empresa}
              </div>
              <div>
                <label>
                  <strong>Nome Fantasia:</strong>
                </label>{" "}
                {currentRegistro.nome_fantasia}
              </div>
              <div>
                <label>
                  <strong>CNPJ:</strong>
                </label>{" "}
                {currentRegistro.cnpj}
              </div>
              <div>
                <label>
                  <strong>Endereço</strong>
                </label>{" "}
                {currentRegistro.endereco}
              </div>

              <Link
                to={"/registros/" + currentRegistro.id}
                className="badge badge-warning"
              >
                Adicionar funcionários
              </Link>
            </div>
          ) : (
              <div>
                <br />
                <p>Click na empresa para expandir suas infos...</p>
              </div>
            )}
        </div>
      </div>
    );
  }
}