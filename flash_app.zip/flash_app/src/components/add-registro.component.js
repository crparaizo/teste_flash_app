import React, { Component } from "react";
import RegistroDataService from "../services/service";

export default class AddRegistro extends Component {
  constructor(props) {
    super(props);
    this.onChangeNomeEmpresa = this.onChangeNomeEmpresa.bind(this);
    this.onChangeNomeFantasia = this.onChangeNomeFantasia.bind(this);
    this.onChangeCnpj = this.onChangeCnpj.bind(this);
    this.onChangeEndereco = this.onChangeEndereco.bind(this);
    this.saveRegistro = this.saveRegistro.bind(this);
    this.newRegistro = this.newRegistro.bind(this);

    this.state = {
      id: null,
      nome_empresa: "",
      nome_fantasia: "",
      cnpj: "",
      endereco: "",
      funcionarios: [{
        nome_funcionario: "",
        sobrenome: "",
        cpf: "",
        email: ""
      }],

      submitted: false
    };
  }

  onChangeNomeEmpresa(e) {
    this.setState({
      nome_empresa: e.target.value
    });
  }

  onChangeNomeFantasia(e) {
    this.setState({
      nome_fantasia: e.target.value
    });
  }

  onChangeCnpj(e) {
    this.setState({
      cnpj: e.target.value
    });
  }

  onChangeEndereco(e) {
    this.setState({
      endereco: e.target.value
    });
  }

  // onChangeFuncionarios(e) {
  //   this.setState({
  //     funcionarios: e.target.value
  //   });
  // }

  saveRegistro() {
    var data = {
      nome_empresa: this.state.nome_empresa,
      nome_fantasia: this.state.nome_fantasia,
      cnpj: this.state.cnpj,
      endereco: this.state.endereco,
      funcionarios: [{
        nome_funcionario: this.state.funcionarios.nome_funcionario,
        sobrenome: this.state.funcionarios.sobrenome,
        cpf: this.state.funcionarios.cpf,
        email: this.state.funcionarios.email
      }]
    };

    RegistroDataService.create(data)
      .then(response => {
        this.setState({
          id: response.data.id,
          nome_empresa: response.data.nome_empresa,
          nome_fantasia: response.data.nome_fantasia,
          cnpj: response.data.cnpj,
          endereco: response.data.endereco,
          funcionarios: [{
            nome_funcionario: response.data.funcionarios.nome_funcionario,
            sobrenome: response.data.funcionarios.sobrenome,
            cpf: response.data.funcionarios.cpf,
            email: response.data.funcionarios.email
          }],

          submitted: true
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  newRegistro() {
    this.setState({
      id: null,
      nome_empresa: "",
      nome_fantasia: "",
      cnpj: "",
      endereco: "",
      funcionarios: [{
        nome_funcionario: "",
        sobrenome: "",
        cpf: "",
        email: ""
      }],

      submitted: false
    });
  }

  render() {
    return (
      <div className="submit-form">
        {this.state.submitted ? (
          <div>
            <h4>You submitted successfully!</h4>
            <button className="btn btn-success" onClick={this.newRegistro}>
              Cadastrar novamente?
            </button>
          </div>
        ) : (
            <div>
              <div className="form-group">
                <label htmlFor="nome_empresa">Nome da Empresa</label>
                <input
                  type="text"
                  className="form-control"
                  id="nome_empresa"
                  required
                  value={this.state.nome_empresa}
                  onChange={this.onChangeNomeEmpresa}
                  name="nome_empresa"
                />
              </div>

              <div className="form-group">
                <label htmlFor="nome_fantasia">Nome Fantasia</label>
                <input
                  type="text"
                  className="form-control"
                  id="nome_fantasia"
                  required
                  value={this.state.nome_fantasia}
                  onChange={this.onChangeNomeFantasia}
                  name="nome_fantasia"
                />
              </div>

              <div className="form-group">
                <label htmlFor="cnpj">CNPJ</label>
                <input
                  type="text"
                  className="form-control"
                  id="cnpj"
                  required
                  value={this.state.cnpj}
                  onChange={this.onChangeCnpj}
                  name="cnpj"
                />
              </div>

              <div className="form-group">
                <label htmlFor="endereco">Endereço</label>
                <input
                  type="text"
                  className="form-control"
                  id="endereco"
                  required
                  value={this.state.endereco}
                  onChange={this.onChangeEndereco}
                  name="endereco"
                />
              </div>

              <button onClick={this.saveRegistro} className="btn btn-success">
                Enviar
            </button>
            </div>
          )}
      </div>
    );
  }
}